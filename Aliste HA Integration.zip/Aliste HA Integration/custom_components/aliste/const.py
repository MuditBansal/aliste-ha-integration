DOMAIN = "aliste"
DEFAULT_NAME = "Aliste Device"

# You can add more constants here as needed for your integration

# Default scan interval in seconds for updating device states
SCAN_INTERVAL = 60
